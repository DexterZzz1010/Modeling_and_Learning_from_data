p_noise_power = 1e-7;
acc_noise_power = 1e-5;
deta_noise_power = 1e-4;
wind_power = 0;